﻿using System;

class Program
{
    static void Main()
    {
        // Пример массива целых чисел
        int[] numbers = { 8, 16, 4, 21, 11, 5 };

        int maxNumber = FindMaxNumber(numbers);

        Console.WriteLine($"Наибольшее значение в массиве: {maxNumber}");
    }

    static int FindMaxNumber(int[] array)
    {
        if (array == null || array.Length == 0)
        {
            throw new ArgumentException("Массив не может быть пустым или равным null.");
        }

        int max = array[0];

        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
            }
        }

        return max;
    }
}
